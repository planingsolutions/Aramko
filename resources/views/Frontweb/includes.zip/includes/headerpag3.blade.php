<nav class="navbar navbar-expand-lg navbar-light bg-light rounded" style="background-color: rgba(161, 155, 155, 0.426);">
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample09" aria-controls="navbarsExample09" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarsExample09">
                <ul class="navbar-nav mr-auto">
                @foreach(LaravelLocalization::getSupportedLocales() as $localeCode => $properties)
                    <li class="nav-item dropdown" style="padding: 10px;">
                        <a rel="alternate" hreflang="{{ $localeCode }}" href="{{ LaravelLocalization::getLocalizedURL($localeCode, null, [], true) }}">
                            {{ $properties['native'] }}
                        </a>
                    </li>
                    @endforeach
                    
                    <li class="nav-item" style="padding: 10px;">
                    <a class="nav-link"  href="#Servicess">{{__('translation.nav_Services')}}</a>
                    </li>
                  
                    <li class="nav-item" style="padding: 10px;" >
                        <a class="nav-link" href="#About">{{__('translation.nav_About')}}</a>
                    </li>
                    <li class="nav-item active" style="padding: 10px;" >
                        <a class="nav-link" href="{{route('interiorde​sign')}}">{{__('translation.nav_home')}}<span class="sr-only">(current)</span></a>
                    </li>
                </ul>
                @foreach($socialmedia as $webbb)
                        <a class="navbar-brand" href="{{url('')}}"><img src="{{asset('public/img/'.$webbb->Images[0])}}" style="width: 150px; height: 80px;"></a>
               @endforeach
            </div>
    </nav>